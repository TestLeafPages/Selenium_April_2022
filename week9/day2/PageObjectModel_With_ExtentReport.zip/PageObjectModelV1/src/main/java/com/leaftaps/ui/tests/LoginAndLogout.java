package com.leaftaps.ui.tests;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leaftaps.ui.base.ProjectSpecificMethods;
import com.leaftaps.ui.pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setData() {
		testName = "LeaftapsLogin";
		testDescription = "Login with positive credential";
		testCategory = "smoke";
		testAuthor = "Hari";
		excelFileName = "tc002";
	}

	@Test(dataProvider = "getData")
	public void tc001(String username, String password) throws IOException {
		
		
		new LoginPage(driver)
		.typeUsername(username)
		.typePassword(password)
		.clickLoginButton();
		
	}
}
