package com.leaftaps.ui.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.leaftaps.ui.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	public LoginPage(RemoteWebDriver inwardDriver) {
		this.driver = inwardDriver;
		this.node = node;
	}
	public LoginPage typeUsername(String username) throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(username);
			reportStep(username+" Username is entered successfully", "pass");
		} catch (Exception e) {
			reportStep("Username is not entered successfully..."+e, "fail");
		}
		return this;
	}
	public LoginPage typePassword(String password) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep(password+" password is entered successfully", "pass");
		} catch (Exception e) {
			reportStep("Password is not entered successfully..."+e, "fail");
		}
		return this;
	}
	public WelcomePage clickLoginButton() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked..."+e, "fail");
		}
		return new WelcomePage(driver);
	}
}
